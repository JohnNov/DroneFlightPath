//ORIGINAL CODE BELOW:

#include <iostream>
#include <sstream>
#include "AssignCoordinates.h"
#include "FlightTime.h"
#include <string>
#include <SFML/Graphics.hpp>
#include <TGUI/TGUI.hpp>
#include "Drone.h"
#include <vector>

/* WE NEED TO INTEGRATE CORNER METHOD.  USER PROVIDES TOP LEFT CORNER AND BOTTOM RIGHT CORNER.
THE PROGRAM THEN TAKES CARE OF THE REST.

ALSO WE NEED TO CONSIDER MULTIPLE DRONES.!!!
*/
int numDrones(){
    string input = " ";
    int x = 0;

    while (true) {
       cout << "How many drones will you be working with? : ";
       getline(cin, input);
       stringstream myStream(input);

       if (myStream >> x)
         break;
       cout << "Invalid number, please try again" << endl;
     }
     cout << "You entered: " << x << endl << endl;
}

int main()
{
    FlightTime flightTime;
    Drone* aDrone= new Drone(41.485738, -71.52799, 41.485738, -71.526539, 41.486989, -71.527993, 41.486989, -71.526539);    //All the starting coordinates
    aDrone->assignCoordinates(*aDrone); ///This should be a drone function
    //flightPath(*aDrone);
    flightTime.flightPath(*aDrone);
    int num = numDrones();      ///We prompt the user for number of drones he has.
    //vector<Drone> theDrones (num);
    //Drone* theDrones[num];
    flightTime.flightLoop();
    return 0;
}


