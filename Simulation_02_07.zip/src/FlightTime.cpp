#include "FlightTime.h"
#include <iostream>
#include <string>
#include <fstream>
#include <unistd.h>
#include <Drone.h>
#include <numeric>
#include <cmath>

using namespace std;

FlightTime::FlightTime()
{
    //ctor
}

int FlightTime::booleanFileRead()
{
    ifstream booleanFile ("booleanFile.txt");
    string booleanFileResult;
    booleanFile.open("booleanFile.txt", ifstream::in);
    getline (booleanFile,booleanFileResult);
    booleanFile.close();
    if(booleanFileResult=="True") //function returns 0 if strings are equal hence the '!'
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void FlightTime::flightLoop()
{
    int count = 0;
    string latInstruction;
    string longInstruction;
    string imgString1 = "php -f fetchImage.php";
    string jpgExt = ".jpg";
    string phpExt = ".php";
    string fetchLatInst = "php -f fetchLat.php ";

    while(true)
    {
        string stringCount = to_string(count);
        string completeImgString = imgString1 +" "+stringCount+jpgExt;       //completeImgString is now php -f fetchImage.php 0.jpg--  Where 0 is whatever "count" is

        // cout << "Image: "<<system(completeImgString.c_str())<<endl;  //The + i is pointing to the argument character. So for example +3 is pointing to '-f'
        system("php -f fetchImage.php 0.jpg");

        if(booleanFileRead()==1)
        {
            latInstruction = fetchLatInst+"Lat"+stringCount+phpExt;     //
            system(latInstruction.c_str());     //.c_str() needed for system.
            string mvLatInst = "mv Lat"+stringCount+"txt"+" positiveLat";
            system(mvLatInst.c_str());  //We move the Latitude over to positiveLat folder
        }
        sleep(4);
    }
}
void FlightTime::flightPath(Drone &aDrone){ ///Tells drones to fly up, down, left and right until they reach center

    double difference = fabs(71.527993-71.526539);
    cout<<"difference is "<<difference<<endl;   //difference in this hardcoded case is 143.055

    int count = 0;
    while(difference>0)
    {
        difference = difference-.0004;
        count++;
    }

    cout<<"count is "<<count;

    for(int i = 0; i<4; i++)    //THis is a hardcoded for loop to find the center
    {
        /*
        The closer it gets to the center the less time it takes on each iteration
        so it's not THAT bad of a bug.
        OR
        we could go until distance is -nan
        */
        aDrone.goRight();
        aDrone.goUp();
        aDrone.goLeft();
        aDrone.goDown();
    }
}




FlightTime::~FlightTime()
{
    //dtor
}
