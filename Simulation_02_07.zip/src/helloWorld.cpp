#include "helloWorld.h"

helloWorld::helloWorld()
{
    //ctor
}

helloWorld::~helloWorld()
{
    //dtor
}
