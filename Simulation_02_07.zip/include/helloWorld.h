#ifndef HELLOWORLD_H
#define HELLOWORLD_H


class helloWorld
{
    public:
        helloWorld();
        virtual ~helloWorld();
    protected:
    private:
};

#endif // HELLOWORLD_H
