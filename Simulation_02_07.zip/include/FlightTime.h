#ifndef FLIGHTTIME_H
#define FLIGHTTIME_H
#include <Drone.h>

class FlightTime
{
public:
    FlightTime();
    void flightLoop();
    int booleanFileRead();
    virtual ~FlightTime();
    void flightPath(Drone &aDrone);


protected:
private:
};

#endif // FLIGHTTIME_H
