//ORIGINAL CODE BELOW:

#include <iostream>
#include <sstream>
#include "AssignCoordinates.h"
#include "FlightTime.h"
#include <string>
#include <SFML/Graphics.hpp>
#include <TGUI/TGUI.hpp>
#include "Drone.h"
#include <vector>

/* WE NEED TO INTEGRATE CORNER METHOD.  USER PROVIDES TOP LEFT CORNER AND BOTTOM RIGHT CORNER.
THE PROGRAM THEN TAKES CARE OF THE REST.

ALSO WE NEED TO CONSIDER MULTIPLE DRONES.!!!
*/
int numDrones(){
    string input = " ";
    int x = 0;

    while (true) {
       cout << "How many drones will you be working with? : ";
       getline(cin, input);
       stringstream myStream(input);

       if (myStream >> x)
         break;
       cout << "Invalid number, please try again" << endl;
     }
     cout << "You entered: " << x << endl << endl;
     return x;
}

void pushDronesOnVector(int numOfDrones, vector<Drone> &v){     ///Pushes x number of drones onto the drone Vector

    if(numOfDrones > 0){
        Drone aDrone;
        v.push_back(aDrone);
        numOfDrones--;
        cout<<"numOfDrones is "<<numOfDrones<<endl;
        pushDronesOnVector(numOfDrones, v);
}
}

void areaToBeSearched(double &topLeftLat, double &topLeftLong, double &bottomRightLat, double &bottomRightLong){        ///Prompts user for the area that has to be searched

        double userInput;

        for(int i = 0; i<4; i++){

            string input = " ";

            while (true) {
                if(i == 0)
                    cout << "Enter top left Latitude : "<<endl;
                else if(i == 1)
                    cout<<"Enter top left Longitude : "<<endl;
                else if(i == 2)
                    cout<<"Enter bottom right Latitude : "<<endl;
                else
                    cout<<"Enter bottom right Longitude : "<<endl;
                getline(cin, input);
                stringstream myStream(input);

                if (myStream >> userInput)
                  break;
                cout << "Invalid number, please try again" << endl;
             }
             cout << "You entered: " << userInput << endl << endl;
                if(i==0)
                    topLeftLat = userInput;
                else if(i == 1)
                    topLeftLong = userInput;
                else if(i == 2)
                    bottomRightLat = userInput;
                else
                    bottomRightLong = userInput;
    }
}



void partitionArea(vector<Drone> &v, int numberOfDrones, double topLeftLat, double topLeftLong, double bottomRightLat, double bottomRightLong){

    double totalHorizontalWidth = bottomRightLong - topLeftLong;
    double individualHorizontalWidth = (totalHorizontalWidth/numberOfDrones);
    double droneBottomLeftLat, droneBottomLeftLong, droneBottomRightLat, droneBottomRightLong, droneTopLeftLat, droneTopLeftLong, droneTopRightLat, droneTopRightLong;

    for(int i = 0; i<numberOfDrones; i++){

        droneBottomLeftLat = bottomRightLat;
        droneBottomLeftLong = topLeftLong + (i*individualHorizontalWidth);    ///We're subtracting because to the left of the meridian of 0
        droneBottomRightLat = bottomRightLat;
        droneBottomRightLong = topLeftLong + ((i+1)*individualHorizontalWidth);///We're subtracting because we're to the left of the 0 meridian

        droneTopLeftLat = topLeftLat;
        droneTopLeftLong = topLeftLong + (i*individualHorizontalWidth);
        droneTopRightLat = droneTopLeftLat;
        droneTopRightLong = topLeftLong + ((i+1)*individualHorizontalWidth);

        Drone aDrone(droneBottomLeftLat, droneBottomLeftLong, droneBottomRightLat, droneBottomRightLong, droneTopLeftLat, droneTopLeftLong, droneTopRightLat, droneTopRightLong);


        cout<<"topLeft is "<<droneTopLeftLat<<","<<droneTopLeftLong<<endl;
        cout<<"topRight is "<<droneTopRightLat<<","<<droneTopRightLong<<endl;

        cout<<endl;

        cout<<"bottomLeft is "<<droneBottomLeftLat<<","<<droneBottomLeftLong<<endl;
        cout<<"bottomRight is "<<droneBottomRightLat<<","<<droneBottomRightLong<<endl;


        v.push_back(aDrone);

    }

}


int main()
{

    double topLeftLat, topLeftLong, bottomRightLat, bottomRightLong;

    //areaToBeSearched(topLeftLat, topLeftLong, bottomRightLat, bottomRightLong);
    topLeftLat = 41.48698;
    topLeftLong = -71.527993;
    bottomRightLat = 41.485738;
    bottomRightLong = -71.526539;

    int numSpirals;
    int numOfDrones = numDrones();      ///We prompt the user for number of drones he has.

    vector<Drone> droneVector;

    //pushDronesOnVector(numOfDrones, droneVector);

    partitionArea(droneVector, numOfDrones, topLeftLat, topLeftLong, bottomRightLat, bottomRightLong);


    FlightTime flightTime;
    //Drone aDrone(41.485738, -71.52799, 41.485738, -71.526539, 41.486989, -71.527993, 41.486989, -71.526539);    //All the starting coordinates

   // numSpirals = aDrone.numTimesSpiralCenter();
    //aDrone.beginFlight(numSpirals);

    for(int i = 0; i<droneVector.size();i++){
        numSpirals = droneVector[i].numTimesSpiralCenter();
        cout<<"numSpirals is "<<numSpirals<<endl;
        droneVector[i].beginFlight(numSpirals);
    }

    flightTime.flightLoop();
    return 0;
}


