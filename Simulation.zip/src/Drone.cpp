/*
In order to randomly spawn a Drone we've gotta be able to keep track of all the
locations that the Drone can travel ('.')

We need to go through the map and every time we come across a plain dot we store its
location in the vector AND we keep track of how many dots we've got.

So for example we have 50 dots then we do a random number generator from 1-50.  If
for example we get a 23 then we spawn the Drone at whatever location the 23'rd dot
is at!


So what should we use to store this?


WAIT FIRST LETS SPAWN THE Drone AT A HARD CODED LOCATION!


*/
#include <iostream>
#include <string>
#include "Drone.h"
#include <vector>
#include <numeric>
#include <cmath>

using namespace std;

Drone::Drone(double bottomLeftLat, double bottomLeftLong, double bottomRightLat, double bottomRightLong, double topLeftLat, double topLeftLong, double topRightLat, double topRightLong)
{

}

void Drone::setStartingPoint(double startingLat, double startingLong)
{
    _startingLat = startingLat;
    _startingLong = startingLong;

    _currentLat = _startingLat;
    _currentLong = _startingLong;
}

void Drone::goRight()   //We should start storing the new coordinates that we'll take the average of and send them to setLimit
{

    // cout<<"_currentLong is now "<<_currentLong<<endl;
    // cout<<"_rightLimit "<<_rightLimit<<endl;

    while((_currentLong+.0001)<=_rightLimit)    //.0001 is the next space that the drone will move to
    {
        _currentLong = _currentLong + .0001;    //.0001 should really be a random number
        cout<<_currentLat<<","<<_currentLong<<endl;
    }

    setBottomLimit(_bottomLimit+.0002);


    double distancex = (_currentLat - _centerLat) * (_currentLat - _centerLat);
    double distancey = (_currentLong - _centerLong) * (_currentLong - _centerLong);

    double distance = sqrt(distancex - distancey);
    if(distance<=.00001)
    {
        noRoomLeft = true;
    }


}

void Drone::goUp()
{

//cout<<"Hii"<<endl;

    vector<double> longsForNewRightLimit;

    while((_currentLat+.0001)<=_topLimit)
    {

        //We'd also have to fetch the current Long when this is hooked up to GPS for accurate new Right Limit.
        //So we'd update current Long by whatever the GPS says now.

        longsForNewRightLimit.push_back(_currentLong);

        _currentLat = _currentLat + .0001;
        cout<<_currentLat<<","<<_currentLong<<endl;

    }

    double average = accumulate( longsForNewRightLimit.begin(), longsForNewRightLimit.end(), 0.0)/longsForNewRightLimit.size(); //Don't know how this works but it finds the average apparently.

    // setRightLimit(average+.0001);   //We have to decrement the average by a little bit.
    //Do we need to do that?  Can't we just set it based off the old limit and add plus .0001
    setRightLimit(_rightLimit-.0002);

    double distancex = (_currentLat - _centerLat) * (_currentLat - _centerLat);
    double distancey = (_currentLong - _centerLong) * (_currentLong - _centerLong);

    double distance = sqrt(distancex - distancey);
    cout<<"distance is "<<distance<<endl;
    if(distance<=.00001)
    {
        cout<<"Derp"<<endl;
        noRoomLeft = true;
    }

}

void Drone::goLeft()
{
    // cout<<"_currentLong is now "<<_currentLong<<endl;
//   cout<<"_leftLimit "<<_leftLimit<<endl;
    while((_currentLong-.0001)>=_leftLimit)    //.0001 is the next space that the drone will move to
    {
        _currentLong = _currentLong - .0001;    //.0001 should really be a random number
        cout<<_currentLat<<","<<_currentLong<<endl;
    }

    setTopLimit(_topLimit-.0002);


    double distancex = (_currentLat - _centerLat) * (_currentLat - _centerLat);
    double distancey = (_currentLong - _centerLong) * (_currentLong - _centerLong);

    double distance = sqrt(distancex - distancey);
    if(distance<=.00001)
    {
        noRoomLeft = true;
    }

}

void Drone::goDown()
{
    //  cout<<"_currentLat is now "<<_currentLat<<endl;
//   cout<<"_bottom "<<_bottomLimit<<endl;

    while((_currentLat-.0001)>=_bottomLimit)
    {
        _currentLat = _currentLat - .0001;
        cout<<_currentLat<<","<<_currentLong<<endl;
    }

    setLeftLimit(_leftLimit+.0002);

    double distancex = (_currentLat - _centerLat) * (_currentLat - _centerLat);
    double distancey = (_currentLong - _centerLong) * (_currentLong - _centerLong);

    double distance = sqrt(distancex - distancey);
    if(distance<=.00001)
    {
        noRoomLeft = true;
    }

}

void Drone::setHorizontalLimits(double theLeftLimit, double theRightLimit)
{
    _rightLimit = theRightLimit;
    _leftLimit = theLeftLimit;

}

bool Drone::outOfRoom()
{

    return noRoomLeft;

}

void Drone::findCenter(double bottomLeftLong, double bottomRightLong, double bottomLeftLat, double topLeftLat)
{

    double ToAddFromLeft = bottomRightLong-bottomLeftLong;
    double toAddFromBottom = topLeftLat-bottomLeftLat;

    cout<<"ToAddFromLeft is "<<ToAddFromLeft<<endl;
    cout<<"ToAddFromBottom is "<<toAddFromBottom<<endl;


    _centerLat = bottomLeftLat+toAddFromBottom;
    _centerLong = bottomLeftLong+ToAddFromLeft;



}

void Drone::setVerticalLimits(double topLimit, double bottomLimit)
{

    _topLimit = topLimit;
    _bottomLimit = bottomLimit+.0001;

}

void Drone::setRightLimit(double rightLimit)
{
    _rightLimit = rightLimit;
}

void Drone::setLeftLimit(double leftLimit)
{
    _leftLimit = leftLimit;
}

void Drone::setTopLimit(double topLimit)
{
    _topLimit = topLimit;
}
void Drone::setBottomLimit(double bottomLimit)
{
    _bottomLimit = bottomLimit;
}
/*
double Drone::getRightLimit(){
    return _rightLimit;
}
*/

void Drone::getHorizontalLimits(double &leftLimit, double &rightLimit)
{
    leftLimit = _leftLimit;
    rightLimit = _rightLimit;
}

void Drone::getverticalLimits()
{

}

void Drone::setLocation(int x, int y)
{
    _x = x;
    _y = y;
}

void Drone::getLocation(int &x, int &y)     //We use reference for multiple parameters
{
    x = _x;
    y = _y;
}
