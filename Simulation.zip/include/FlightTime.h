#ifndef FLIGHTTIME_H
#define FLIGHTTIME_H

class FlightTime
{
public:
    FlightTime();
    void flightLoop();
    int booleanFileRead();
    virtual ~FlightTime();

protected:
private:
};

#endif // FLIGHTTIME_H
