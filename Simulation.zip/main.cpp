


//ORIGINAL CODE BELOW:

#include <iostream>
#include "AssignCoordinates.h"
#include "FlightTime.h"
#include <string>
#include <SFML/Graphics.hpp>
#include <TGUI/TGUI.hpp>

//http://stackoverflow.com/questions/5527665/why-am-i-getting-string-does-not-name-a-type-error
//DON'T BUT USING NAMESPACE STD IN HEADERS!!!

//https://tgui.eu/tutorials/v0.7/linux/
void login(tgui::EditBox::Ptr username, tgui::EditBox::Ptr password)
{
    std::cout << "Username: " << username->getText().toAnsiString() << std::endl;
    std::cout << "Password: " << password->getText().toAnsiString() << std::endl;
}

void loadWidgets( tgui::Gui& gui )
{
    // Load the black theme
    auto theme = std::make_shared<tgui::Theme>("Black.txt");

    // Get a bound version of the window size
    // Passing this to setPosition or setSize will make the widget automatically update when the view of the gui changes
    auto windowWidth = tgui::bindWidth(gui);
    auto windowHeight = tgui::bindHeight(gui);

    // Create the background image (picture is of type tgui::Picture::Ptr or std::shared_widget<Picture>)
    auto picture = std::make_shared<tgui::Picture>("aluminium.jpg");
    picture->setSize(tgui::bindMax(800, windowWidth), tgui::bindMax(600, windowHeight));
    gui.add(picture);

    // Create the username edit box

    tgui::EditBox::Ptr editBoxnumDrones = theme->load("EditBox");
    editBoxnumDrones->setSize(windowWidth * 2/3, windowHeight / 8);
    editBoxnumDrones->setPosition(windowWidth / 6, windowHeight* 1/25);
    editBoxnumDrones->setDefaultText("Number of Drones");
    gui.add(editBoxnumDrones, "Username");



    tgui::EditBox::Ptr editBoxTopLeftLat = theme->load("EditBox");
    editBoxTopLeftLat->setSize(windowWidth * 2/3, windowHeight / 8);
    editBoxTopLeftLat->setPosition(windowWidth / 6, windowHeight / 6);
    editBoxTopLeftLat->setDefaultText("TopLeftLat");
    gui.add(editBoxTopLeftLat, "Username");

    // Create the password edit box
    tgui::EditBox::Ptr editBoxTopLeftLong = theme->load("EditBox");
    editBoxTopLeftLong->setSize(windowWidth * 2/3, windowHeight / 8);
    editBoxTopLeftLong->setPosition(windowWidth / 6, windowHeight /3);
    editBoxTopLeftLong->setPasswordCharacter('*');
    editBoxTopLeftLong->setDefaultText("TopLeftLong");
    gui.add(editBoxTopLeftLong, "Password");

    tgui::EditBox::Ptr editBoxBottomRightLat = theme->load("EditBox");
    editBoxBottomRightLat->setSize(windowWidth * 2/3, windowHeight / 8);
    editBoxBottomRightLat->setPosition(windowWidth / 6, windowHeight /2);
    editBoxBottomRightLat->setPasswordCharacter('*');
    editBoxBottomRightLat->setDefaultText("BottomRightLat");
    gui.add(editBoxBottomRightLat, "Password");

   // int spot = (windowHeight/2)+10;

    tgui::EditBox::Ptr editBoxBottomRightLong = theme->load("EditBox");
    editBoxBottomRightLong->setSize(windowWidth * 2/3, windowHeight / 8);
    editBoxBottomRightLong->setPosition(windowWidth / 6, windowHeight/1.5);
    editBoxBottomRightLong->setPasswordCharacter('*');
    editBoxBottomRightLong->setDefaultText("BottomRightLong");
    gui.add(editBoxBottomRightLong, "Password");

    // Create the login button
    tgui::Button::Ptr button = theme->load("Button");
    button->setSize(windowWidth / 2, windowHeight / 6);
    button->setPosition(windowWidth / 4, windowHeight * 8/10);
    button->setText("Partition Area");
    gui.add(button);


    // Call the login function when the button is pressed
    button->connect("pressed", login, editBoxTopLeftLat, editBoxTopLeftLong);
}

int main()
{
    // Create the window
    sf::RenderWindow window(sf::VideoMode(600, 400), "SARNET");
    tgui::Gui gui(window);

    try
    {
        // Load the widgets
        loadWidgets(gui);
    }
    catch (const tgui::Exception& e)
    {
        std::cerr << "Failed to load TGUI widgets: " << e.what() << std::endl;
        return 1;
    }

    // Main loop
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            // When the window is closed, the application ends
            if (event.type == sf::Event::Closed)
                window.close();

            // When the window is resized, the view is changed
            else if (event.type == sf::Event::Resized)
            {
                window.setView(sf::View(sf::FloatRect(0, 0, event.size.width, event.size.height)));
                gui.setView(window.getView());
            }

            // Pass the event to all the widgets
            gui.handleEvent(event);
        }

        window.clear();

        // Draw all created widgets
        gui.draw();

        window.display();
    }

    return EXIT_SUCCESS;
}



/* WE NEED TO INTEGRATE CORNER METHOD.  USER PROVIDES TOP LEFT CORNER AND BOTTOM RIGHT CORNER.
THE PROGRAM THEN TAKES CARE OF THE REST.

ALSO WE NEED TO CONSIDER MULTIPLE DRONES.!!!

int main()
{

    AssignCoordinates assignCoordinates;
    assignCoordinates.startGame();

    FlightTime flightTime;
    flightTime.flightLoop();


    return 0;
}
*/

